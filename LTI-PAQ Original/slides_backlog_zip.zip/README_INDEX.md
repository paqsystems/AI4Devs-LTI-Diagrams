# Slides, Backlog y Checklist — ATS LTI MVP

Este paquete contiene los materiales ejecutivos y de planificación del MVP:

- **Presentaciones ejecutivas**: resumen de negocio y arquitectura.
- **Backlog de funcionalidades (RICE/WSJF)**.
- **Checklist de revisión ejecutiva**: control de calidad antes de entrega.

---
## Estructura de carpetas

📂 Slides/
- ATS_LTI_Presentacion_MVP.pptx
- ATS_LTI_OnePager.pptx
- ATS_LTI_Resumen_Ejecutivo.pdf

📂 Backlog/
- Backlog_MVP_RICE_WSJF.csv

📂 Control/
- Checklist_Revision_Ejecutiva.md
